package com.smartBanking.utils;

import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.*;



public class EmailUtil {
	
	    private static final String FROM = "yourbank@gmail.com";
	    private static final String USER = "yourbank@gmail.com";
	    private static final String PASS = "your-app-password";

	    public static void sendEmail(String to, String subject, String body) {
	        try {
	            Properties props = new Properties();
	            props.put("mail.smtp.auth", "true");
	            props.put("mail.smtp.starttls.enable", "true");
	            props.put("mail.smtp.host", "smtp.gmail.com");
	            props.put("mail.smtp.port", "587");

	            Session session = Session.getInstance(props, new Authenticator() {
	                protected PasswordAuthentication getPasswordAuthentication() { return new PasswordAuthentication(USER, PASS); }
	            });

	            Message message = new MimeMessage(session);
	            message.setFrom(new InternetAddress(FROM));
	            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
	            message.setSubject(subject);
	            message.setText(body);
	            Transport.send(message);
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	    }
	}



