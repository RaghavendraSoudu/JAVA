package com.smartBanking.utils;

public class AccountUtil {
	
	    public static String generateAccountNumber(){
	        long t = System.currentTimeMillis() % 1000000000L;
	        return "SB" + String.format("%010d", t + (int)(Math.random()*999));
	    }
	}



