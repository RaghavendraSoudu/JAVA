package com.smartBanking.utils;

import java.util.Random;

public class OTPUtil {

	    public static String generateOtp() {
	        Random r = new Random();
	        int num = 100000 + r.nextInt(900000);
	        return String.valueOf(num);
	    }
	}



