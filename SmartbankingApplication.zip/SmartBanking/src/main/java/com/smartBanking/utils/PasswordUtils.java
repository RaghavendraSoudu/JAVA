package com.smartBanking.utils;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordUtils {

	
	    private static final BCryptPasswordEncoder enc = new BCryptPasswordEncoder();
	    private static String lastPlainTemp = null;

	    public static String hashPassword(String raw) { return enc.encode(raw); }
	    public static boolean matches(String raw, String hashed) { return enc.matches(raw, hashed); }

	    public static String generateTempPasswordPlain() {
	        String t = "T@" + (int)(Math.random()*9000 + 1000);
	        lastPlainTemp = t;
	        return t;
	    }

	    // helper used by AdminServiceImpl to get plain temp after generation (we set it before hashing)
	    public static String getLastGeneratedTemp() { return lastPlainTemp; }

	    // helper that generates & returns plain temp and also stores lastPlainTemp
	    public static String generateTempPasswordPlainAndRemember() {
	        return generateTempPasswordPlain();
	    }
	}


