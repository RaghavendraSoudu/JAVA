package com.smartBanking.dao;


import com.smartBanking.model.Accounts;
import com.smartBanking.model.Transactions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface TransactionRepository extends JpaRepository<Transactions, Long> {

    List<Transactions> findTop10ByAccountOrderByIdDesc(String accountNumber); // if you have Account relation
    List<Transactions> findByCustomerId(Long customerId);
	List<Transactions> findTop10ByFromAccountOrderByIdDesc(Accounts account);
	List<Transactions> findTop10ByFromAccountOrderByIdDesc(String accountNumber);
}
