package com.smartBanking.ServiceImpl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.hibernate.grammars.hql.HqlParser.CurrentTimeFunctionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartBanking.Dto.CustomerRequest;
import com.smartBanking.Dto.LoanApplicationRequest;
import com.smartBanking.Dto.MiniStatement;
import com.smartBanking.Dto.TransferRequest;
import com.smartBanking.Service.CustomerService;
import com.smartBanking.dao.AccountsRepository;
import com.smartBanking.dao.CustomerRepository;
import com.smartBanking.dao.LoanRepository;
import com.smartBanking.dao.TransactionRepository;
import com.smartBanking.enums.ApprovalStatus;
import com.smartBanking.enums.TransactionType;
import com.smartBanking.model.Accounts;
import com.smartBanking.model.Customer;
import com.smartBanking.model.Loans;
import com.smartBanking.model.Transactions;
import com.smartBanking.utils.PasswordUtils;

import jakarta.transaction.Transactional;

@Service
public class CustomerServiceImpl implements CustomerService {

	 @Autowired private CustomerRepository customerRepo;
	    @Autowired private AccountsRepository accountRepo;
	    @Autowired private TransactionRepository txnRepo;
	    @Autowired private LoanRepository loanRepo;

	    
	    @Transactional
	@Override
	public boolean completeRegistration(long customerId, String newPassword, CustomerRequest kycData) {
		Customer c = customerRepo.findById(customerId).orElseThrow(() -> new RuntimeException("Customer not found"));
        c.setName(kycData.getName() != null ? kycData.getName() : c.getName());
        c.setPhone(kycData.getPhone() != null ? kycData.getPhone() : c.getPhone());
        c.setAadhaar(kycData.getAadhaar() != null ? kycData.getAadhaar() : c.getAadhaar());
        c.setPasswordHash(PasswordUtils.hashPassword(newPassword));
        c.setRegistered(true);
     
        c.setTempPassword(null);
        customerRepo.save(c);

        // ensure account exists
        Optional<Accounts> opt = accountRepo.findByCustomerId(c.getId());
        if (!opt.isPresent()) {
            Accounts acct = new Accounts();
            acct.setCustomer(c);
            acct.setAccountNumber(com.smartBanking.utils.AccountUtil.generateAccountNumber());
            acct.setBalance(0);
            
            accountRepo.save(acct);
        }
        return true;
    }

//	@Override
//	public List<MiniStatement> getMiniStatementByAccountNumber(String accountNumber) {
//		 // combine from & to lists to show last 10 - for simplicity get 10 from fromAccount OR toAccount
//		List<Transactions> from = txnRepo.findTop10ByAccountOrderByIdDesc(accountNumber);
////		List<Transactions> from = txnRepo.findTop10ByFromAccountOrderByIdDesc();
////        List<Transactions> to = txnRepo.findTop10ByFromAccountOrderByIdDesc(accountNumber);
////        List<Transactions> to = txnRepo.findTop10ByToAccountOrderByIdDesc(accountNumber);
//        List<Transactions> merged = new ArrayList<>();
//        merged.addAll(from);
//        Collection<? extends Transactions> to;
//		merged.addAll(to);
//        // sort by id desc (approx timestamp order) and limit 10
//        merged.sort((a,b) -> Long.compare(b.getId(), a.getId()));
//        return merged.stream().limit(10).map(t ->{
//       
//            MiniStatement m = new MiniStatement();
//            m.setTxnId(t.getId());
//            m.setAmount(t.getAmount() != null ? t.getAmount() : java.math.BigDecimal.ZERO);
//            m.setTxnType(t.getTxnType() != null ? t.getTxnType(): "Transfer");           +
//            m.setDescription(t.getRemarks());
//            m.setCounterparty(t.getToAccount() != null ? t.getToAccount() : t.getFromAccount());
//            return m;
//        }).collect(Collectors.toList());
//    }
//		return null;
//	}

@Override
public List<MiniStatement> getMiniStatementByAccountNumber(String accountNumber) {
    // fetch last 10 outgoing transactions
    List<Transactions> from = txnRepo.findTop10ByFromAccountOrderByIdDesc(accountNumber);
    // fetch last 10 incoming transactions
//    List<Transactions> to = txnRepo.findTop10ByToAccountOrderByIdDesc(accountNumber);

    List<Transactions> merged = new ArrayList<>();
    merged.addAll(from);
    Collection<? extends Transactions> to = null;
	merged.addAll(to);

    // sort by id desc (approx timestamp order) and limit 10
    merged.sort((a, b) -> Long.compare(b.getId(), a.getId()));

    List<MiniStatement> miniStatements = new ArrayList<>();
    int count = 0;
    for (Transactions t : merged) {
        if (count >= 10) break;

        MiniStatement m = new MiniStatement();
        m.setTxnId(t.getId());

        if (t.getAmount() != null) {
            m.setAmount(t.getAmount());
        } else {
            m.setAmount(0);
        }

        if (t.getTxnType() != null) {
            m.setTxnType(t.getTxnType());
        } else {
        	m.setTxnType(TransactionType.Transfer);
           
        }

        if (t.getCreatedAt() != null) {
            m.setTimestamp(t.getCreatedAt());
        } else {
            m.setTimestamp(java.time.LocalDateTime.now());
        }

        m.setDescription(t.getRemarks());

        if (t.getToAccount() != null) {
            m.setCounterparty(t.getToAccount());
        } else {
            m.setCounterparty(t.getFromAccount());
        }

        miniStatements.add(m);
        count++;
    }

    return miniStatements;
}

	@Override
	public boolean transfer(TransferRequest req) {
		 Accounts from = accountRepo.findById(req.getFromAccountId()).orElseThrow(() -> new RuntimeException("From account not found"));
	        Accounts to = accountRepo.findByAccountNumber(req.getToAccountNumberOrUpi()).orElseThrow(() -> new RuntimeException("Destination account not found"));
	        double amt = req.getAmount();
	        if (from.getBalance() < amt) throw new RuntimeException("Insufficient funds");
	        from.setBalance(from.getBalance());
	       
	        to.setBalance(to.getBalance());
	        accountRepo.save(from);
	        accountRepo.save(to);

	        Transactions debit = new Transactions();
	        debit.setAmount(from.getBalance());
	        debit.setFromAccount(from.getAccountNumber());
	        debit.setToAccount(to.getAccountNumber());
	        debit.setAmount(req.getAmount());
	        debit.setTxnType(com.smartBanking.enums.TransactionType.DEBIT);
	        debit.setRemarks(req.getRemarks());
	        txnRepo.save(debit);

	        Transactions credit = new Transactions();
	        credit.setFromAccount(from.getAccountNumber());
	        credit.setToAccount(to.getAccountNumber());
	        credit.setAmount(req.getAmount());
	        credit.setTxnType(TransactionType.CREDIT);
	        credit.setRemarks("Received from " + from.getAccountNumber());
	        txnRepo.save(credit);
		return true;
	}
	       

	@Override
	public long applyLoan(LoanApplicationRequest req) {
		 Customer c = customerRepo.findById(req.getCustomerId()).orElseThrow(() -> new RuntimeException("Customer not found"));
	        Loans loan = new Loans();
//	        loan.setCustomer(c.getId().longValue());
	       
//	        loan.setAmount(req.getAmount().toBigInteger());
	        loan.setTermMonths(req.getTermMonths());
	        loan.setStatus(ApprovalStatus.PENDING);
	       
//	        loan.setCreatedAt(new java.sql.Timestamp(System.currentTimeMillis()));
	        loanRepo.save(loan);
	        return loan.getId();
	}

}