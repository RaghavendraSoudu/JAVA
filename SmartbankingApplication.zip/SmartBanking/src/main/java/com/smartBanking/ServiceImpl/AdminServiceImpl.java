package com.smartBanking.ServiceImpl;



import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartBanking.Dto.CustomerRequest;
import com.smartBanking.Dto.CustomerResponse;
import com.smartBanking.Service.AdminService;
import com.smartBanking.dao.AccountsRepository;
import com.smartBanking.dao.AdminRepository;
import com.smartBanking.dao.CustomerRepository;
import com.smartBanking.dao.LoanRepository;
import com.smartBanking.dao.OTPRepository;
import com.smartBanking.dao.TransactionRepository;
import com.smartBanking.enums.ApprovalStatus;
import com.smartBanking.model.Accounts;
import com.smartBanking.model.Customer;
import com.smartBanking.model.Loans;
import com.smartBanking.model.Transactions;
import com.smartBanking.utils.AccountUtil;
import com.smartBanking.utils.EmailUtil;
import com.smartBanking.utils.PasswordUtils;

import jakarta.transaction.Transactional;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired private CustomerRepository customerRepo;
    @Autowired private AccountsRepository accountRepo;
    @Autowired private LoanRepository loanRepo;
    @Autowired private TransactionRepository txnRepo;
    @Autowired private AdminRepository adminRepo;
    @Autowired private OTPRepository otpRepo;
	@Override
	public CustomerResponse createCustomer(CustomerRequest request) {
		// create customer (using your existing POJO 'customer')
        Customer c = new Customer();
        c.setName(request.getName());
        c.setEmail(request.getEmail());
        c.setPhone(request.getPhone());
        c.setAadhaar(request.getAadhaar());
        // mark not registered
       
        c.setRegistered(false);
       
        // generate temp password (plain), store hashed in DB
        String plainTemp = PasswordUtils.generateTempPasswordPlain();
        c.setTempPassword(PasswordUtils.hashPassword(plainTemp));
        customerRepo.save(c);

        // create account (Accounts POJO)
        Accounts acct = new Accounts();
       
        acct.setCustomer(c);
        acct.setCustomer(c);
      
        String acctNo = AccountUtil.generateAccountNumber();
        acct.setAccountNumber(acctNo);
        acct.setBalance(500);
      
       
        // send temp password via email (plainTemp)
        EmailUtil.sendEmail(c.getEmail(),
                "SmartBank - Your temporary password",
                "Hello " + c.getName() + ",\n\nYour temporary password is: " + plainTemp +
                "\nPlease login and complete registration.\n\nRegards,\nSmartBank");

        CustomerResponse resp = new CustomerResponse();
        resp.setCustomerId(c.getId());
        resp.setTempPassword(plainTemp);
        resp.setMessage("Customer created and temporary password emailed.");
        return resp;
        
       
    }

	@Override
	public boolean resetCustomerPassword(long customerId, String newPassword) {
		
		Customer c = customerRepo.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        c.setPasswordHash(PasswordUtils.hashPassword(newPassword));
        c.setTempPassword(null);
       
        customerRepo.save(c);
        return true;
    
	}
		
	
	@Override
	public Loans approveLoan(long loanId, long adminId) {
	     Loans loan = loanRepo.findById(loanId).orElseThrow(() -> new RuntimeException("Loan not found"));
	     
	     loan.setStatus(ApprovalStatus.APPROVAL);
	        loan.setApprovedByAdmin(adminId);
	        
	        loanRepo.save(loan);
	        return loan;
	}
	@Override
	public Loans rejectLoan(long loanId, long adminId, String reason) {
		 Loans loan = loanRepo.findById(loanId).orElseThrow(() -> new RuntimeException("Loan not found"));
	        loan.setStatus(ApprovalStatus.REJECTED);
	        loan.setApprovedByAdmin(adminId);
	        loanRepo.save(loan);
	        return loan;
	}
	@Override
	public boolean deposit(long accountId, double amount) {
		Accounts acct = accountRepo.findById(accountId).orElseThrow(() -> new RuntimeException("Account not found"));
		acct.setBalance(acct.getBalance()+ amount);
       
       accountRepo.save(acct);

        Transactions t = new Transactions();
      
        t.setAmount(amount);
        
        txnRepo.save(t);
        return true;
	}
	@Override
	public boolean withdraw(long accountId, double amount) {
		 Accounts acct = accountRepo.findById(accountId).orElseThrow(() -> new RuntimeException("Account not found"));
	        if (acct.getBalance() < amount) throw new RuntimeException("Insufficient funds");
	        acct.setBalance(acct.getBalance()-amount);
	       
	        accountRepo.save(acct);

	        Transactions t = new Transactions();
	      
	     
	        t.setAmount(amount);
	      
	        txnRepo.save(t);
	        return true;
		
	}
	}

    
	