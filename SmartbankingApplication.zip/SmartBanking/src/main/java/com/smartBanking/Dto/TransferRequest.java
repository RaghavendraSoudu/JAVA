package com.smartBanking.Dto;


public class TransferRequest {
    private long fromAccountId;
    private String toAccountNumberOrUpi;
    private double amount;
    private String remarks;
    // getters/setters
    public long getFromAccountId() { return fromAccountId; }
    public void setFromAccountId(long fromAccountId) { this.fromAccountId = fromAccountId; }
    public String getToAccountNumberOrUpi() { return toAccountNumberOrUpi; }
    public void setToAccountNumberOrUpi(String toAccountNumberOrUpi) { this.toAccountNumberOrUpi = toAccountNumberOrUpi; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
}
