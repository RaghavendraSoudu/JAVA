package com.smartBanking.Dto;

import java.math.BigDecimal;

import com.smartBanking.enums.Purpose;
public class LoanApplicationRequest {
    private long customerId;
    private double amount;
    private int termMonths;
    private Purpose purpose;
    // getters/setters
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getTermMonths() {
		return termMonths;
	}
	public void setTermMonths(int termMonths) {
		this.termMonths = termMonths;
	}
	public Purpose getPurpose() {
		return purpose;
	}
	public void setPurpose(Purpose purpose) {
		this.purpose = purpose;
	}
   
}
