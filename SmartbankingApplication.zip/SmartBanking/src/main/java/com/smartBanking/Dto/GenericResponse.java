package com.smartBanking.Dto;

import lombok.Data;

@Data
public class GenericResponse {

    private boolean success;
    private String message;  // e.g., "Transfer successful" or "Invalid OTP"
    private Object data;  // Optional: e.g., new balance or loan ID
}
