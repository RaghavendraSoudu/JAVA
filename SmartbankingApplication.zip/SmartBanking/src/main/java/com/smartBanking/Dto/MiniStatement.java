package com.smartBanking.Dto;


import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;

import org.hibernate.annotations.CreationTimestamp;

import com.smartBanking.enums.TransactionType;
public class MiniStatement {
    private long txnId;
    private TransactionType txnType;
    private double amount;
    private LocalDateTime timestamp;
    private String description;
    private String counterparty;
    private String FromAccount;
    private String ToAccount;
    private String Remark;
    private Timestamp  createdAt;
    
    
	public MiniStatement(long txnId, TransactionType txnType, double amount, LocalDateTime timestamp,
			String description, String counterparty, String fromAccount, String toAccount, String remark,
			Timestamp createdAt) {
		super();
		this.txnId = txnId;
		this.txnType = txnType;
		this.amount = amount;
		this.timestamp = timestamp;
		this.description = description;
		this.counterparty = counterparty;
		FromAccount = fromAccount;
		ToAccount = toAccount;
		Remark = remark;
		this.createdAt = createdAt;
	}


	public MiniStatement() {
		super();
	}


	public long getTxnId() {
		return txnId;
	}


	public void setTxnId(long txnId) {
		this.txnId = txnId;
	}


	public TransactionType getTxnType() {
		return txnType;
	}


	public void setTxnType(TransactionType txnType) {
		this.txnType = txnType;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public LocalDateTime getTimestamp() {
		return timestamp;
	}


	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getCounterparty() {
		return counterparty;
	}


	public void setCounterparty(String counterparty) {
		this.counterparty = counterparty;
	}


	public String getFromAccount() {
		return FromAccount;
	}


	public void setFromAccount(String fromAccount) {
		FromAccount = fromAccount;
	}


	public String getToAccount() {
		return ToAccount;
	}


	public void setToAccount(String toAccount) {
		ToAccount = toAccount;
	}


	public String getRemark() {
		return Remark;
	}


	public void setRemark(String remark) {
		Remark = remark;
	}


	public Timestamp getCreatedAt() {
		return createdAt;
	}


	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}
    
}