package com.smartBanking.Dto;


public class CustomerResponse {
    private long customerId;
    private String tempPassword;
    private String message;
    // getters/setters
    public long getCustomerId() { return customerId; }
    public void setCustomerId(long customerId) { this.customerId = customerId; }
    public String getTempPassword() { return tempPassword; }
    public void setTempPassword(String tempPassword) { this.tempPassword = tempPassword; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}


