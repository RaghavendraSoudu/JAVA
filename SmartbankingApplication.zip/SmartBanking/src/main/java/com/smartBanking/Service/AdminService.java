package com.smartBanking.Service;


import com.smartBanking.Dto.CustomerRequest;
import com.smartBanking.Dto.CustomerResponse;
import com.smartBanking.model.Loans;


public interface AdminService {
  CustomerResponse createCustomer(CustomerRequest request);
    boolean resetCustomerPassword(long customerId, String newPassword);
    Loans approveLoan(long loanId, long adminId);
    Loans rejectLoan(long loanId, long adminId, String reason);
    boolean deposit(long accountId, double amount);
    boolean withdraw(long accountId, double amount);
}
