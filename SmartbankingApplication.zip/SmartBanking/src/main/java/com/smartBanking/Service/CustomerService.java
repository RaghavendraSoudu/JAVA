package com.smartBanking.Service;

import java.util.List;

import com.smartBanking.Dto.CustomerRequest;
import com.smartBanking.Dto.LoanApplicationRequest;
import com.smartBanking.Dto.MiniStatement;
import com.smartBanking.Dto.TransferRequest;

public interface CustomerService {
    boolean completeRegistration(long customerId, String newPassword, CustomerRequest kycData);
    List<MiniStatement> getMiniStatementByAccountNumber(String accountNumber);
    boolean transfer(TransferRequest req);
    long applyLoan(LoanApplicationRequest req);
}

