package com.smartBanking.enums;

public enum Purpose {
	HIGER_STUDIES,
	FARMING,
	VEHICLE_LOAN,
	PERSONAL_LOAN,
	HOME_LOAN,
	GOLD_LOAN,
	BUSSINESS_LOAN

}
