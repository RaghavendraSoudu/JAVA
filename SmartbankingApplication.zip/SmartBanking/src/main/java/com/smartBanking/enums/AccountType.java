package com.smartBanking.enums;

public enum AccountType {
	SAVINGS,
	CURRENT

}
