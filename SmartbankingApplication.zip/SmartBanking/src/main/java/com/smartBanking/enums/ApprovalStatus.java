package com.smartBanking.enums;

public enum ApprovalStatus {
	PENDING,
	APPROVAL,
	REJECTED

}
