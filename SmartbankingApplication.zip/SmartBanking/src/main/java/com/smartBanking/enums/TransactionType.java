package com.smartBanking.enums;

public enum TransactionType {
	DEBIT,
	CREDIT,
	Transfer

}
