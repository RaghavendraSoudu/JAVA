package com.smartBanking.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "admin")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Admin {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="username",nullable = false, unique = true, length = 50)
    private String userName;

    @Column(name="passwordhash",nullable = false, length = 255)
    private String passwordHash;

    @Column(name="fullname",length = 100)
    private String fullName;
    @Column(name="role")
    private String role ="ADMIN";

	public Admin(Long id, String userName, String passwordHash, String fullName, String role) {
		super();
		this.id = id;
		this.userName = userName;
		this.passwordHash = passwordHash;
		this.fullName = fullName;
		this.role = role;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	@Override
	public String toString() {
		return "Admin [id=" + id + ", userName=" + userName + ", passwordHash=" + passwordHash + ", fullName="
				+ fullName + ", role=" + role + "]";
	}

	public Admin(String userName, String passwordHash, String fullName) {
		super();
		this.userName = userName;
		this.passwordHash = passwordHash;
		this.fullName = fullName;
	}

	public Admin() {
		super();
	}
    
}