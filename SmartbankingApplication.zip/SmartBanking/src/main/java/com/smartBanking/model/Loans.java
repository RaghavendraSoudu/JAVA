package com.smartBanking.model;

import java.time.LocalDateTime;

import com.smartBanking.enums.ApprovalStatus;
import com.smartBanking.enums.Purpose;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="loans")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Loans {

	   
		@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

		//many loans belongs to one customer
	    @ManyToOne
	    @JoinColumn(name="customer_id", nullable=false)
	    private Customer customer;

	    @Column(name="amount",nullable=false)
	    private Double amount;

	    @Column(name="termMonths",nullable=false)
	    private int termMonths;

	    @Column(name="status")
	    private ApprovalStatus status; // APPROVED / REJECTED
	    
	    @Column(name="loanPurpose")
	    private Purpose LoanPurposs;

	   //when applied
		private LocalDateTime applicationDate;
		//when its approved 
	    private LocalDateTime approvalDate;

	    //Which admin approves
	    private Long approvedByAdmin;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Customer getCustomer() {
			return customer;
		}

		public void setCustomer(Customer customer) {
			this.customer = customer;
		}

		public Double getAmount() {
			return amount;
		}

		public void setAmount(Double amount) {
			this.amount = amount;
		}

		public int getTermMonths() {
			return termMonths;
		}

		public void setTermMonths(int termMonths) {
			this.termMonths = termMonths;
		}

		public ApprovalStatus getStatus() {
			return status;
		}

		public void setStatus(ApprovalStatus status) {
			this.status = status;
		}

		public Purpose getLoanPurposs() {
			return LoanPurposs;
		}

		public void setLoanPurposs(Purpose loanPurposs) {
			LoanPurposs = loanPurposs;
		}

		public LocalDateTime getApplicationDate() {
			return applicationDate;
		}

		public void setApplicationDate(LocalDateTime applicationDate) {
			this.applicationDate = applicationDate;
		}

		public LocalDateTime getApprovalDate() {
			return approvalDate;
		}

		public void setApprovalDate(LocalDateTime approvalDate) {
			this.approvalDate = approvalDate;
		}

		public Long getApprovedByAdmin() {
			return approvedByAdmin;
		}

		public void setApprovedByAdmin(Long approvedByAdmin) {
			this.approvedByAdmin = approvedByAdmin;
		}

		@Override
		public String toString() {
			return "Loans [id=" + id + ", customer=" + customer + ", amount=" + amount + ", termMonths=" + termMonths
					+ ", status=" + status + ", LoanPurposs=" + LoanPurposs + ", applicationDate=" + applicationDate
					+ ", approvalDate=" + approvalDate + ", approvedByAdmin=" + approvedByAdmin + "]";
		}

		public Loans(Customer customer, Double amount, int termMonths, ApprovalStatus status, Purpose loanPurposs,
				LocalDateTime applicationDate, LocalDateTime approvalDate, Long approvedByAdmin) {
			super();
			this.customer = customer;
			this.amount = amount;
			this.termMonths = termMonths;
			this.status = status;
			LoanPurposs = loanPurposs;
			this.applicationDate = applicationDate;
			this.approvalDate = approvalDate;
			this.approvedByAdmin = approvedByAdmin;
		}

		public Loans() {
			super();
		}
	    
}