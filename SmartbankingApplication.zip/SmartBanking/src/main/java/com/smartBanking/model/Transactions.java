package com.smartBanking.model;


import java.sql.Timestamp;
import java.time.LocalDateTime;

import com.smartBanking.enums.TransactionType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="transactions")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Transactions {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @ManyToOne
	    @JoinColumn(name="account_id", nullable=false)
	    private Accounts account;

	    @Enumerated(EnumType.STRING)
	    @Column(name="txntype",nullable=false)
	    private TransactionType txnType;  // CREDIT / DEBIT

	    @Column(nullable=false, precision=18, scale=2)
	    private Double amount;

	    private Timestamp  txnTime;
	    
	    private LocalDateTime createdAt;
	    
	    private String Remarks;
	    
	    private String toAccount;
	    
	    private String fromAccount;
	    
	    
	    
	    

	    public String getToAccount() {
			return toAccount;
		}

		public void setToAccount(String toAccount) {
			this.toAccount = toAccount;
		}

		public String getFromAccount() {
			return fromAccount;
		}

		public void setFromAccount(String fromAccount) {
			this.fromAccount = fromAccount;
		}

		@Column(name="desciption")
	    private String description;

	    @Column(length=20)
	    private String counterparty;

		public String getRemarks() {
			return Remarks;
		}

		public void setRemarks(String remarks) {
			Remarks = remarks;
		}

		public Transactions() {
			super();
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Accounts getAccount() {
			return account;
		}

		public void setAccount(Accounts account) {
			this.account = account;
		}

		public TransactionType getTxnType() {
			return txnType;
		}

		public void setTxnType(TransactionType txnType) {
			this.txnType = txnType;
		}

		public Double getAmount() {
			return amount;
		}

		public void setAmount(Double amount) {
			this.amount = amount;
		}

		public Timestamp getTxnTime() {
			return txnTime;
		}

		public void setTxnTime(Timestamp txnTime) {
			this.txnTime = txnTime;
		}

		public LocalDateTime getCreatedAt() {
			return createdAt;
		}

		public void setCreatedAt(LocalDateTime createdAt) {
			this.createdAt = createdAt;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getCounterparty() {
			return counterparty;
		}

		public void setCounterparty(String counterparty) {
			this.counterparty = counterparty;
		}

		@Override
		public String toString() {
			return "Transactions [id=" + id + ", account=" + account + ", txnType=" + txnType + ", amount=" + amount
					+ ", txnTime=" + txnTime + ", createdAt=" + createdAt + ", description=" + description
					+ ", counterparty=" + counterparty + "]";
		}

		public Transactions(Accounts account, TransactionType txnType, Double amount, Timestamp txnTime,
				LocalDateTime createdAt, String description, String counterparty) {
			super();
			this.account = account;
			this.txnType = txnType;
			this.amount = amount;
			this.txnTime = txnTime;
			this.createdAt = createdAt;
			this.description = description;
			this.counterparty = counterparty;
		}

		public void setFromAccount1(String accountNumber) {
			// TODO Auto-generated method stub
			
		}

				}