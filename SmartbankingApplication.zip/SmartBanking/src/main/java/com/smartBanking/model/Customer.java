package com.smartBanking.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name="name",nullable=false)
    private String name;

    @Column(name="email",nullable=false, unique=true)
    private String email;

    @Column(name="phone",unique=true, nullable=false)
    private String phone;

    @Column(name="aadhar",unique=true,nullable=false)
    private String aadhaar;

    //checking weather customer is registered or not
    @Column(name="isRegistered",nullable = false)
    private boolean isRegistered;

    @Column(name="tempPassword")
    private String tempPassword;

    @Column(name="passwordHast",length = 255)
    private String passwordHash;

    // Relationships
    //One customer has many accounts
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Accounts> accounts;

    //One customer has many loans
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Loans> loans;
    //One customer has many OTPs
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OTP> otps;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAadhaar() {
		return aadhaar;
	}
	public void setAadhaar(String aadhaar) {
		this.aadhaar = aadhaar;
	}
	public boolean isRegistered() {
		return isRegistered;
	}
	public void setRegistered(boolean isRegistered) {
		this.isRegistered = isRegistered;
	}
	public String getTempPassword() {
		return tempPassword;
	}
	public void setTempPassword(String tempPassword) {
		this.tempPassword = tempPassword;
	}
	public String getPasswordHash() {
		return passwordHash;
	}
	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}
	public List<Accounts> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<Accounts> accounts) {
		this.accounts = accounts;
	}
	public List<Loans> getLoans() {
		return loans;
	}
	public void setLoans(List<Loans> loans) {
		this.loans = loans;
	}
	public List<OTP> getOtps() {
		return otps;
	}
	public void setOtps(List<OTP> otps) {
		this.otps = otps;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", email=" + email + ", phone=" + phone + ", aadhaar="
				+ aadhaar + ", isRegistered=" + isRegistered + ", tempPassword=" + tempPassword + ", passwordHash="
				+ passwordHash + ", accounts=" + accounts + ", loans=" + loans + ", otps=" + otps + "]";
	}
	public Customer(String name, String email, String phone, String aadhaar, boolean isRegistered, String tempPassword,
			String passwordHash, List<Accounts> accounts, List<Loans> loans, List<OTP> otps) {
		super();
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.aadhaar = aadhaar;
		this.isRegistered = isRegistered;
		this.tempPassword = tempPassword;
		this.passwordHash = passwordHash;
		this.accounts = accounts;
		this.loans = loans;
		this.otps = otps;
	}
	public Customer() {
		super();
	}
    

}