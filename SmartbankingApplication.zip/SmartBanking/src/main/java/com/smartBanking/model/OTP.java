package com.smartBanking.model;


import java.time.LocalDateTime;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="otps")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OTP {
 
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    //Many Otps belong one customer 
	    @ManyToOne
	    @JoinColumn(name="customer_id", nullable=false)
	    private Customer customer;

	    @Column(name="otpcode",nullable=false, length=6)
	    private String otpCode;

	   
	    @Column(name="expirytime",nullable=false)
	    private LocalDateTime expiryTime;


		public Long getId() {
			return id;
		}


		public void setId(Long id) {
			this.id = id;
		}


		public Customer getCustomer() {
			return customer;
		}


		public void setCustomer(Customer customer) {
			this.customer = customer;
		}

	
		public String getOtpCode() {
			return otpCode;
		}


		public void setOtpCode(String otpCode) {
			this.otpCode = otpCode;
		}


		public LocalDateTime getExpiryTime() {
			return expiryTime;
		}


		public void setExpiryTime(LocalDateTime expiryTime) {
			this.expiryTime = expiryTime;
		}


		@Override
		public String toString() {
			return "OTP [id=" + id + ", customer=" + customer + ", otpCode=" + otpCode + ", expiryTime=" + expiryTime
					+ "]";
		}


		public OTP(Customer customer, String otpCode, LocalDateTime expiryTime) {
			super();
			this.customer = customer;
			this.otpCode = otpCode;
			this.expiryTime = expiryTime;
		}


		public OTP() {
			super();
		}


		
	    

}