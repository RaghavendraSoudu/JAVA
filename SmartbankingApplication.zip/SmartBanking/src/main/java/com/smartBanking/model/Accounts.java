package com.smartBanking.model;

import java.util.List;

import com.smartBanking.enums.AccountType;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="accounts")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Accounts {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    //Many Accounts belongs to one customer 
	    @ManyToOne
	    @JoinColumn(name = "customer_id", nullable = false)
	    private Customer customer;

	    @Column(name="accountnumber",nullable=false, unique=true)
	    private String accountNumber;
	    
	    @Enumerated(EnumType.STRING)
	    @Column(name="account_type")
	    private AccountType accountType;

	    @Column(name="balance",nullable=false)
	    private double balance;
	    
	    //One account many transactions
	    @OneToMany(mappedBy = "account",cascade = CascadeType.ALL, orphanRemoval = true)
	    private List<Transactions> transaction;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public Customer getCustomer() {
			return customer;
		}

		public void setCustomer(Customer customer) {
			this.customer = customer;
		}

		public String getAccountNumber() {
			return accountNumber;
		}

		public void setAccountNumber(String accountNumber) {
			this.accountNumber = accountNumber;
		}

		public AccountType getAccountType() {
			return accountType;
		}

		public void setAccountType(AccountType accountType) {
			this.accountType = accountType;
		}

		public double getBalance() {
			return balance;
		}

		public void setBalance(double balance) {
			this.balance = balance;
		}

		public List<Transactions> getTransaction() {
			return transaction;
		}

		public void setTransaction(List<Transactions> transaction) {
			this.transaction = transaction;
		}

		public Accounts(Customer customer, String accountNumber, AccountType accountType, double balance,
				List<Transactions> transaction) {
			super();
			this.customer = customer;
			this.accountNumber = accountNumber;
			this.accountType = accountType;
			this.balance = balance;
			this.transaction = transaction;
		}

		public Accounts() {
			super();
		}

		@Override
		public String toString() {
			return "Accounts [id=" + id + ", customer=" + customer + ", accountNumber=" + accountNumber
					+ ", accountType=" + accountType + ", balance=" + balance + ", transaction=" + transaction + "]";
		}
	    
	    

}