package com.smartBanking.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.smartBanking.Dto.CustomerRequest;
import com.smartBanking.Dto.LoanApplicationRequest;
import com.smartBanking.Dto.MiniStatement;
import com.smartBanking.Dto.TransferRequest;
import com.smartBanking.Service.CustomerService;
import com.smartBanking.dao.AccountsRepository;
import com.smartBanking.model.Accounts;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/customer")
public class CustomerController {

	

	    @Autowired private CustomerService customerService;
	    @Autowired private AccountsRepository accountRepo;

	    @GetMapping("/complete-registration")
	    public String completeRegPage(HttpSession session, Model m) {
	        Object pending = session.getAttribute("pendingCustomerId");
	        if (pending == null) return "redirect:/login";
	        m.addAttribute("customerId", pending);
	        return "customer-complete-registration";
	    }

	    @PostMapping("/complete-registration")
	    public String completeRegistration(@RequestParam long customerId,
	                                       @RequestParam String newPassword,
	                                       @ModelAttribute CustomerRequest request,
	                                       HttpSession session) {
	        customerService.completeRegistration(customerId, newPassword, request);
	        session.removeAttribute("pendingCustomerId");
	        session.setAttribute("customerId", customerId);
	        session.setAttribute("role", "CUSTOMER");
	        return "redirect:/customer/dashboard";
	    }

	    @GetMapping("/dashboard")
	    public String dashboard(HttpSession session, Model m) {
	        Object cust = session.getAttribute("customerId");
	        if (cust == null) return "redirect:/login";
	        long id = (Long) cust;
	        Accounts acct = accountRepo.findByCustomerId(id).orElse(null);
	        m.addAttribute("account", acct);
	        return "customer-dashboard";
	    }

	    @GetMapping("/mini-statement")
	    public String miniStatement(@RequestParam String accountNumber, Model m) {
	        List<MiniStatement> list = customerService.getMiniStatementByAccountNumber(accountNumber);
	        m.addAttribute("transactions", list);
	        return "customer-ministatement";
	    }

	    @PostMapping("/transfer")
	    public String transfer(@ModelAttribute TransferRequest req, Model m) {
	        try {
	            customerService.transfer(req);
	            m.addAttribute("message","Transfer successful");
	        } catch(Exception e) {
	            m.addAttribute("error", e.getMessage());
	        }
	        return "customer-dashboard";
	    }

	    @PostMapping("/apply-loan")
	    public String applyLoan(@ModelAttribute LoanApplicationRequest req, Model m) {
	        long loanId = customerService.applyLoan(req);
	        m.addAttribute("message","Loan submitted, id: " + loanId);
	        return "customer-dashboard";
	    }
	}
