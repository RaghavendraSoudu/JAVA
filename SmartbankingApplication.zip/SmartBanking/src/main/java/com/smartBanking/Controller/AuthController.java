package com.smartBanking.Controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.smartBanking.Dto.LoginRequest;
import com.smartBanking.dao.AdminRepository;
import com.smartBanking.dao.CustomerRepository;
import com.smartBanking.dao.OTPRepository;
import com.smartBanking.model.Admin;
import com.smartBanking.model.Customer;
import com.smartBanking.model.OTP;
import com.smartBanking.utils.EmailUtil;
import com.smartBanking.utils.OTPUtil;
import com.smartBanking.utils.PasswordUtils;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Optional;

import javax.servlet.http.HttpSession;


@Controller
public class AuthController {
	    @Autowired private AdminRepository adminRepo;
	    @Autowired private CustomerRepository customerRepo;
	    @Autowired private OTPRepository otpRepo;

	    @GetMapping({"/", "/login"})
	    public String loginPage(Model m) {
	        m.addAttribute("loginRequest", new LoginRequest());
	        return "login";
	    }

	    @PostMapping("/login")
	    public String login(@ModelAttribute LoginRequest req, HttpSession session, Model model) {
	        String id = req.getUsernameOrEmail();
	        String pw = req.getPassword();
	        if (id == null || id.trim().isEmpty()) { model.addAttribute("error","Enter username/email"); return "login"; }
	        if (pw == null || pw.trim().isEmpty()) { model.addAttribute("error","Enter password"); return "login"; }

	        // Admin login (by username)
	        Optional<Admin> adminOpt = adminRepo.findByUserName(id);
	        if (adminOpt.isPresent()) {
	            Admin a = adminOpt.get();
	            if(PasswordUtils.matches(pw, a.getPasswordHash())) {
	          
	            	//Already set default role as admin fpr this 
	               session.setAttribute("role", "ADMIN");
	                session.setAttribute("adminId", a.getId());
	                return "redirect:/admin/dashboard";
	            } else { model.addAttribute("error","Invalid admin credentials"); return "login"; }
	        }

	        //Customer login with account number and email
	        Optional<Customer> custOpt = customerRepo.findByEmail(id);
	        if(custOpt.isPresent()){
	            Customer c = custOpt.get();
	            // If not registered -> must use temp password and redirect to complete registration
	            if(!c.isRegistered()) {
	        if (PasswordUtils.matches(pw, c.getTempPassword())) {
	                    session.setAttribute("pendingCustomerId", c.getId());
	                    return "redirect:/customer/complete-registration";
	                } else {
	                    model.addAttribute("error","Invalid temporary password");
	                    return "login";       }
	            }
	            
	            
	            if(PasswordUtils.matches(pw, c.getPasswordHash())) {
	            	String otpCode = OTPUtil.generateOtp();
	            	OTP otp = new OTP();
	            	
	            	otp.setCustomer(c);
	            	otp.setOtpCode(otpCode);
	            	otp.setExpiryTime(LocalDateTime.now().plusMinutes(5));
	            	otpRepo.save(otp);

	    

	                EmailUtil.sendEmail(c.getEmail(), "SmartBank - Your OTP", "Your OTP is: " + otpCode + " (valid 5 minutes)");
	                session.setAttribute("otpCustomerId", c.getId());
	                return "redirect:/verify-otp";
	            } else {
	                model.addAttribute("error","Invalid password");
	                return "login";
	            }
	        }

	        model.addAttribute("error","User not found");
	        return "login";
	    }

	    @GetMapping("/verify-otp")
	    public String verifyOtpPage() { return "verify-otp"; }

	    @PostMapping("/verify-otp")
	    public String verifyOtp(@RequestParam String otp, HttpSession session, Model m) {
	    	Object o =session.getAttribute("otpCustomerId");
	      
	        if (o == null) return "redirect:/login";
	        Long custId = (Long) o;
	        
	        Optional<OTP> otpOpt = otpRepo.findByCustomerId(custId);
	      
	        if(!otpOpt.isPresent()) {m.addAttribute("error", "OTP not found. Request Login Again");
	     return "verify-otp"; }
	        OTP record = otpOpt.get();
	        Timestamp now = new Timestamp(System.currentTimeMillis());
	        if(record.getExpiryTime().isBefore(LocalDateTime.now().plusMinutes(5)))
	        		{m.addAttribute("error","OTP expired. Please login again."); return "verify-otp"; }
	        if (!record.getOtpCode().equals(otp)) { m.addAttribute("error","Invalid OTP"); return "verify-otp"; }

	        // OTP valid
	        session.removeAttribute("otpCustomerId");
	        session.setAttribute("role","CUSTOMER");
	        session.setAttribute("customerId", custId);
	        return "redirect:/customer/dashboard";
	    }


	    @GetMapping("/logout")
	    public String logout(HttpSession session) {
	        session.invalidate();
	        return "redirect:/login";
	    }
	}


