package com.smartBanking.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartBanking.Dto.CustomerRequest;
import com.smartBanking.Dto.CustomerResponse;
import com.smartBanking.Service.AdminService;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/admin")
public class AdminController {
	

	    @Autowired private AdminService adminService;
	    
	    

	    @GetMapping("/dashboard")
	    public String dashboard(HttpSession session, Model model) {
	        if (!"ADMIN".equals(session.getAttribute("role"))) return "redirect:/login";
	        return "admin-dashboard";
	    }

	    @GetMapping("/create-customer")
	    public String createCustomerForm(Model m) 
	    { m.addAttribute("customerRequest", new CustomerRequest()); 
	    return "admin-create-customer";
	    }

	    @PostMapping("/create-customer")
	    public String createCustomer(@ModelAttribute CustomerRequest request, Model m) {
	        CustomerResponse resp = adminService.createCustomer(request);
	        m.addAttribute("message", resp.getMessage() + " Temp: " + resp.getTempPassword());
	        return "admin-create-customer";
	    }

	    @PostMapping("/deposit")
	    public String deposit(@RequestParam long accountId, @RequestParam double amount, Model m) {
	    	adminService.deposit(accountId, amount);
	        adminService.deposit(accountId, amount);
	        
	        m.addAttribute("message","Deposited");
	        return "admin-dashboard";
	    }

	    @PostMapping("/withdraw")
	    public String withdraw(@RequestParam long accountId, @RequestParam double amount, Model m) {
	        adminService.withdraw(accountId, amount);
	        m.addAttribute("message","Withdrawn");
	        return "admin-dashboard";
	    }

	    @PostMapping("/approve-loan")
	    public String approveLoan(@RequestParam long loanId, HttpSession session) {
	        Long adminId = (Long) session.getAttribute("adminId");
	        adminService.approveLoan(loanId, adminId != null ? adminId : 0L);
	        return "redirect:/admin/dashboard";
	    }

	    @PostMapping("/reject-loan")
	    public String rejectLoan(@RequestParam long loanId, @RequestParam String reason, HttpSession session) {
	        Long adminId = (Long) session.getAttribute("adminId");
	        adminService.rejectLoan(loanId, adminId != null ? adminId : 0L, reason);
	        return "redirect:/admin/dashboard";
	    }
	}

	


