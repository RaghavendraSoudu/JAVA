package com.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import org.springframework.transaction.annotation.EnableTransactionManagement;  // NEW
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan(basePackages = "com.smartBanking")  // Scans controllers/services/models
@EnableWebMvc
@EnableJpaRepositories(basePackages = "com.smartBanking.dao")
@EnableTransactionManagement  // NEW: For @Transactional
public class Config {

    @Bean
    public InternalResourceViewResolver internalResourceViewResolver() {  // Fixed name (lowercase 'i')
        InternalResourceViewResolver irvr = new InternalResourceViewResolver();
        irvr.setPrefix("/WEB-INF/views/");
        irvr.setSuffix(".jsp");
        return irvr;
    }

   
}
