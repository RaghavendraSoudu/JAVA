package com.dis;
import java.util.*;

public class Disc {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Please enter how many products you purchased");
	int num=sc.nextInt();
	System.out.println("Are you premium consumer");
	boolean isPremium=sc.nextBoolean();
	int prodValue =(num*1000);
	if(isPremium==true) {
		int dis=prodValue/100;
		int dis1 =(dis*10);
		int dis2 =(dis1*8);
		System.out.println("Hello Primium user after discount your bill is "+dis2);
	}else {
		System.out.println("Your Bill is "+prodValue);
		
	}
	System.out.println("Thanks for shopping visit again");
}
}
