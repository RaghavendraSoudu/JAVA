/**
 * 
 */
/**
 * 
 */
module Discount {
}