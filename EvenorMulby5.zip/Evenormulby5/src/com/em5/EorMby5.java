package com.em5;
import java.util.*;

public class EorMby5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("please aenter a number");
		int num = sc.nextInt();
		
		if(num%2==0) {
			System.out.println("This number is even");
			if(num%5==0) {
				System.out.println("This number is even and devided by 5");
			}
			else {
				System.out.println("number is even but not divisable by 5");
			}
			
			
		}
		else {
			System.out.println("you are provided number is odd");
		}
	}

}
