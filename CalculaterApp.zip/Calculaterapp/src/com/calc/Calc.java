package com.calc;

import java.util.Scanner;

public class Calc {

	public static void main(String[] args) {
		System.out.println("hello Please enter two number values");
		Scanner sc=new Scanner(System.in);
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		
		System.out.println("Now choose which operation do you want +, -,*,%,/");
		String ch=sc.next();
		
		switch(ch){
		case "+":
			System.out.println("Your addition of "+num1+" "+num2+" is "+(num1+num2));
			break;
		case "-":
			System.out.println("Your sub of "+num1+" and "+num2+" is "+(num1-num2));
			break;
		case "*":
			System.out.println("Your mul of "+num1+" and "+num2+" is "+(num1*num2));
			break;
		case "%":
			System.out.println("Your mod of "+num1+" and "+num2+" is "+(num1%num2));
			break;
		case "/":
			System.out.println("Your Div of "+num1+" and "+num2+" is "+(num1/num2));
			break;
			default:
				System.out.println("Please enter correct operation or numbers");
		}
	}
}
